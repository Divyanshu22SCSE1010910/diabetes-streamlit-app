
import os, numpy as np, pandas as pd, joblib, matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.feature_selection import SelectKBest, chi2
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, VotingClassifier, StackingClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix, ConfusionMatrixDisplay
from imblearn.over_sampling import SMOTE

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
DATA = os.path.join(ROOT, "data", "diabetes.csv")
OUT = os.path.join(ROOT, "outputs")
os.makedirs(OUT, exist_ok=True)

print("Loading:", DATA)
df = pd.read_csv(DATA)

# Clean zeros -> NaN -> median impute
cols_with_zero = ["Glucose","BloodPressure","SkinThickness","Insulin","BMI"]
df[cols_with_zero] = df[cols_with_zero].replace(0, np.nan)
imp = SimpleImputer(strategy="median")
df[cols_with_zero] = imp.fit_transform(df[cols_with_zero])

X = df.drop("Outcome", axis=1)
y = df["Outcome"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s = scaler.transform(X_test)
joblib.dump(scaler, os.path.join(OUT,"scaler.joblib"))

# SMOTE
sm = SMOTE(random_state=42)
X_res, y_res = sm.fit_resample(X_train_s, y_train)

# Feature selection
selector = SelectKBest(chi2, k=6)
selector.fit(abs(X_res), y_res)  # chi2 requires non-negative
selected = X.columns[selector.get_support()]
pd.Series(selected).to_csv(os.path.join(OUT,"selected_features.txt"), index=False)

# Models
lr = LogisticRegression(max_iter=1000, random_state=42)
dt = DecisionTreeClassifier(random_state=42)
rf = RandomForestClassifier(n_estimators=300, random_state=42)
svm = SVC(probability=True, gamma="scale", random_state=42)

models = {"LogisticRegression": lr, "DecisionTree": dt, "RandomForest": rf, "SVM": svm}
rows = []
for name, m in models.items():
    m.fit(X_res, y_res)
    pred = m.predict(X_test_s)
    proba = m.predict_proba(X_test_s)[:,1] if hasattr(m,'predict_proba') else None
    acc = accuracy_score(y_test, pred)
    prec = precision_score(y_test, pred)
    rec = recall_score(y_test, pred)
    f1 = f1_score(y_test, pred)
    auc = roc_auc_score(y_test, proba) if proba is not None else float('nan')
    rows.append([name, acc, prec, rec, f1, auc])
    joblib.dump(m, os.path.join(OUT, f"{name.lower()}_model.joblib"))

res = pd.DataFrame(rows, columns=["Model","Accuracy","Precision","Recall","F1","ROC_AUC"])

# Ensembles
voting = VotingClassifier([('lr',lr),('rf',rf),('svm',svm)], voting='soft')
voting.fit(X_res, y_res)
v_pred = voting.predict(X_test_s); v_proba = voting.predict_proba(X_test_s)[:,1]
vres = ["Voting", accuracy_score(y_test,v_pred), precision_score(y_test,v_pred), recall_score(y_test,v_pred),
        f1_score(y_test,v_pred), roc_auc_score(y_test,v_proba)]
joblib.dump(voting, os.path.join(OUT,"voting_model.joblib"))

stack = StackingClassifier([('lr',lr),('rf',rf),('svm',svm)], final_estimator=LogisticRegression(max_iter=1000), cv=5)
stack.fit(X_res, y_res)
s_pred = stack.predict(X_test_s); s_proba = stack.predict_proba(X_test_s)[:,1]
sres = ["Stacking", accuracy_score(y_test,s_pred), precision_score(y_test,s_pred), recall_score(y_test,s_pred),
        f1_score(y_test,s_pred), roc_auc_score(y_test,s_proba)]
joblib.dump(stack, os.path.join(OUT,"stacking_model.joblib"))

allres = pd.concat([res, pd.DataFrame([vres, sres], columns=res.columns)], ignore_index=True)
allres.to_csv(os.path.join(OUT,"all_results.csv"), index=False)
print(allres)

# Confusion matrix for stacking
cm = confusion_matrix(y_test, s_pred)
fig = ConfusionMatrixDisplay(confusion_matrix=cm).plot(values_format='d')
import matplotlib.pyplot as plt
plt.title("Confusion Matrix - Stacking")
plt.tight_layout()
plt.savefig(os.path.join(OUT,"confusion_matrix.png"))

# Feature importances (RF)
fi = pd.Series(rf.feature_importances_, index=X.columns).sort_values(ascending=False)
ax = fi.plot(kind='bar', figsize=(7,4), title="Feature Importances (RandomForest)")
plt.tight_layout()
plt.savefig(os.path.join(OUT,"feature_importances.png"))
print("Saved outputs to:", OUT)
