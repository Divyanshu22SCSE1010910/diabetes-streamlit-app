
Diabetes Prediction - MTE Demo (Windows 11)

Project ID: BT1492
Student: Divyanshu (Enrollment: 22131010946, Admission: 22SCSE1010910)
Guide: Mr. B. Thillaieswaran
Title: Early Prediction of Diabetes using Machine Learning with Ensemble and Feature Selection Approaches

1) Double-click 'run_train.bat' (first run creates venv and installs packages). 
   This trains models and generates 'outputs' (results + plots + saved models).
2) Double-click 'run_app.bat' to launch the Streamlit demo in your browser.
3) Use images in 'outputs/' for PPT and report.

Note: If your college requires the original PIMA CSV, replace data/diabetes.csv with the official one (same column names).
