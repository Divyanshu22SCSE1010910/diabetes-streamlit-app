
# ===============================
# ETE ANALYSIS SCRIPT
# Diabetes Prediction Project
# ===============================

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.feature_selection import SelectKBest, chi2
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from imblearn.over_sampling import SMOTE

print("Starting ETE Comparative Analysis...")

# Load dataset
df = pd.read_csv("diabetes.csv")
X = df.drop("Outcome", axis=1)
y = df["Outcome"]

# Preprocessing
imputer = SimpleImputer(strategy="median")
X = pd.DataFrame(imputer.fit_transform(X), columns=X.columns)

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42, stratify=y
)

smote = SMOTE(random_state=42)
X_train, y_train = smote.fit_resample(X_train, y_train)

def evaluate_models(models, Xtr, Xte, phase):
    rows = []
    for name, model in models.items():
        model.fit(Xtr, y_train)
        preds = model.predict(Xte)
        rows.append({
            "Phase": phase,
            "Model": name,
            "Accuracy": accuracy_score(y_test, preds),
            "Precision": precision_score(y_test, preds),
            "Recall": recall_score(y_test, preds),
            "F1-Score": f1_score(y_test, preds)
        })
    return rows

models = {
    "Logistic Regression": LogisticRegression(max_iter=1000),
    "Decision Tree": DecisionTreeClassifier(),
    "Random Forest": RandomForestClassifier(),
    "SVM": SVC(probability=True)
}

# WITHOUT Feature Selection
results = evaluate_models(models, X_train, X_test, "Without Feature Selection")

# WITH Feature Selection
selector = SelectKBest(score_func=chi2, k=5)
X_fs = selector.fit_transform(abs(X_scaled), y)

Xtr_fs, Xte_fs, ytr_fs, yte_fs = train_test_split(
    X_fs, y, test_size=0.2, random_state=42, stratify=y
)

Xtr_fs, ytr_fs = smote.fit_resample(Xtr_fs, ytr_fs)

results += evaluate_models(models, Xtr_fs, Xte_fs, "With Feature Selection")

# Save results
df_results = pd.DataFrame(results)
df_results.to_excel("ete_comparison_results.xlsx", index=False)

print("SUCCESS: ete_comparison_results.xlsx generated")
